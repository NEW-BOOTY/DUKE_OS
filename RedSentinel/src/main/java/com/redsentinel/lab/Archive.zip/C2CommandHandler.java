/*
 * Copyright © 2025 Devin B. Royal.
 * All Rights Reserved.
 */

package com.redsentinel.lab;

import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import javax.crypto.spec.GCMParameterSpec;
import java.security.SecureRandom;
import java.util.Base64;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;

public final class C2CommandHandler {

    private static final Logger LOGGER = Logger.getLogger(C2CommandHandler.class.getName());

    private static final int GCM_TAG_LENGTH = 128;
    private static final int GCM_IV_LENGTH = 12;

    public static void initiateCommandControl() {
        LOGGER.info("[RedSentinel™] C2CommandHandler simulating secure C2 channel...");

        try (Scanner scanner = new Scanner(System.in)) {
            SecretKey secretKey = generateSymmetricKey();
            byte[] iv = generateIV();

            System.out.print("Enter simulated C2 command to encrypt: ");
            String command = scanner.nextLine();

            String encrypted = encryptCommand(command, secretKey, iv);
            String decrypted = decryptCommand(encrypted, secretKey, iv);

            LOGGER.info("Encrypted Command (Base64): " + encrypted);
            LOGGER.info("Decrypted Command (for verification): " + decrypted);

        } catch (Exception e) {
            LOGGER.log(Level.SEVERE, "C2 simulation encountered a critical error.", e);
        }
    }

    private static SecretKey generateSymmetricKey() throws Exception {
        KeyGenerator keyGen = KeyGenerator.getInstance("AES");
        keyGen.init(256); // AES-256
        return keyGen.generateKey();
    }

    private static byte[] generateIV() {
        byte[] iv = new byte[GCM_IV_LENGTH];
        new SecureRandom().nextBytes(iv);
        return iv;
    }

    private static String encryptCommand(String command, SecretKey key, byte[] iv) throws Exception {
        Cipher cipher = Cipher.getInstance("AES/GCM/NoPadding");
        GCMParameterSpec gcmSpec = new GCMParameterSpec(GCM_TAG_LENGTH, iv);
        cipher.init(Cipher.ENCRYPT_MODE, key, gcmSpec);
        byte[] encrypted = cipher.doFinal(command.getBytes());
        return Base64.getEncoder().encodeToString(encrypted);
    }

    private static String decryptCommand(String encryptedBase64, SecretKey key, byte[] iv) throws Exception {
        byte[] encrypted = Base64.getDecoder().decode(encryptedBase64);
        Cipher cipher = Cipher.getInstance("AES/GCM/NoPadding");
        GCMParameterSpec gcmSpec = new GCMParameterSpec(GCM_TAG_LENGTH, iv);
        cipher.init(Cipher.DECRYPT_MODE, key, gcmSpec);
        byte[] decrypted = cipher.doFinal(encrypted);
        return new String(decrypted);
    }
}

/*
 * Copyright © 2025 Devin B. Royal.
 * All Rights Reserved.
 */
